#!/usr/bin/env python3
"""Step 2 - transcribe the cleaned audio with Meta's Omnilingual ASR (CTC, 1600 languages,
includes isiZulu) through sherpa-onnx.  Whisper has no isiZulu; this model does and it
is language-agnostic CTC, so no language id is required.

The model accepts at most ~40 s, so we decode 20 s windows with a 10 s hop.

usage: python 02_transcribe.py cleaned.wav {300M|1B} out.json [chunk_s] [hop_s]
Writes  out.json  (start, text, tokens, token-times) and prints one line per window.
"""
import sys, json, time
import numpy as np
import soundfile as sf
import sherpa_onnx

wav, size, out = sys.argv[1], sys.argv[2], sys.argv[3]
CH = float(sys.argv[4]) if len(sys.argv) > 4 else 20.0
HOP = float(sys.argv[5]) if len(sys.argv) > 5 else 10.0

d = f"models/sherpa-onnx-omnilingual-asr-1600-languages-{size}-ctc-int8-2025-11-12/"
rec = sherpa_onnx.OfflineRecognizer.from_omnilingual_asr_ctc(
    model=d + "model.int8.onnx", tokens=d + "tokens.txt", num_threads=2)

x, sr = sf.read(wav, dtype="float32")
rows, s, t0 = [], 0.0, time.time()
while s < len(x) / sr:
    seg = x[int(s * sr):int((s + CH) * sr)]
    if len(seg) < sr:
        break
    seg = seg / (np.abs(seg).max() + 1e-6) * 0.7          # peak-normalise each window
    st = rec.create_stream()
    st.accept_waveform(sr, seg)
    rec.decode_stream(st)
    r = st.result
    rows.append((s, r.text.strip(), list(r.tokens), list(r.timestamps)))
    print(f"{s:6.1f} {r.text.strip()}", flush=True)
    s += HOP
json.dump(rows, open(out, "w"))
print("time", round(time.time() - t0))
