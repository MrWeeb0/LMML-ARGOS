#!/usr/bin/env python3
"""Step 5 - inspect the model's per-frame character posteriors around a hit, and plot them.

usage: python 05_show_posteriors.py posteriors.npy T0 T1 [out.png]
Prints every frame where the model is not >=90% sure of 'blank', with its top-3 symbols,
and (optionally) saves a heat-map of P(symbol | frame) for the window.
"""
import sys
import numpy as np

L = np.load(sys.argv[1])
t0, t1 = float(sys.argv[2]), float(sys.argv[3])
out = sys.argv[4] if len(sys.argv) > 4 else None
sym = ["_"] + list("abcdefghijklmnopqrstuvwxyz' ")      # "_" = CTC blank
P = np.exp(L)

for f in range(int(t0 * 50), int(t1 * 50)):
    idx = np.argsort(-P[f])[:3]
    if idx[0] != 0 or P[f, 0] < 0.9:
        print(f"{f/50:7.2f} " + "  ".join(f"{sym[i]}:{P[f, i]:.2f}" for i in idx))

if out:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    a, b = int(t0 * 50), int(t1 * 50)
    fig, ax = plt.subplots(figsize=(13, 5))
    im = ax.imshow(P[a:b, 1:].T, aspect="auto", origin="lower", cmap="magma", vmin=0, vmax=1,
                   extent=[t0, t1, 0, len(sym) - 1])
    ax.set_yticks(np.arange(len(sym) - 1) + 0.5)
    ax.set_yticklabels(["' " if s == "'" else ("sp" if s == " " else s) for s in sym[1:]], fontsize=7)
    ax.set_xlabel("time (s)"); ax.set_ylabel("symbol")
    ax.set_title("Omnilingual-ASR 300M: P(symbol | frame), cleaned audio")
    fig.colorbar(im, label="probability")
    fig.tight_layout(); fig.savefig(out, dpi=110)
