#!/usr/bin/env python3
"""Step 3 - dump frame-level CTC log-posteriors (a-z, apostrophe, space, blank).

Greedy text output drops quiet words, so for keyword search we keep the full posterior
matrix instead.  Frame rate is 20 ms (320 samples @ 16 kHz).
Column 0 is the CTC blank, which is token id 0 (<s>) in this model - NOT id 1 (<pad>).

usage: python 03_ctc_posteriors.py {300M|1B} cleaned.wav out.npy
"""
import sys, time
import numpy as np
import soundfile as sf
import onnxruntime as ort

size, wav, out = sys.argv[1], sys.argv[2], sys.argv[3]
d = f"models/sherpa-onnx-omnilingual-asr-1600-languages-{size}-ctc-int8-2025-11-12/"
so = ort.SessionOptions(); so.intra_op_num_threads = 2
sess = ort.InferenceSession(d + "model.int8.onnx", so, providers=["CPUExecutionProvider"])

tok = {}
for line in open(d + "tokens.txt", encoding="utf8"):
    p = line.rstrip("\n").rsplit(" ", 1)
    tok[int(p[1])] = p[0]
chars = "abcdefghijklmnopqrstuvwxyz' "
cid = {}
for i, t in tok.items():
    if t in chars and len(t) == 1 and t not in cid:
        cid[t] = i
cols = [0] + [cid[c] for c in chars]          # col 0 = blank

x, sr = sf.read(wav, dtype="float32")
FR, CORE, MARG = 320, 20 * sr, 2 * sr          # 20 s core + 2 s context either side
L = np.full((len(x) // FR + 2, len(cols)), -30, np.float32)
t0 = time.time()
for st in range(0, len(x), CORE):
    a, b = max(0, st - MARG), min(len(x), st + CORE + MARG)
    seg = x[a:b]
    seg = seg / (np.abs(seg).max() + 1e-6) * 0.7
    lg = sess.run(None, {"x": seg[None, :].astype(np.float32)})[0][0]
    lg = lg - lg.max(1, keepdims=True)
    lp = lg - np.log(np.exp(lg).sum(1, keepdims=True))          # log-softmax over full vocab
    f0 = (st - a) // FR
    sub = lp[f0:f0 + CORE // FR][:, cols]
    n0 = st // FR
    L[n0:n0 + len(sub)] = sub[:len(L) - n0]
    print(st // sr, round(time.time() - t0), flush=True)
np.save(out, L)
print("frames", L.shape, "blank-argmax fraction", (L.argmax(1) == 0).mean())
