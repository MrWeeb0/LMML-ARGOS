#!/usr/bin/env python3
"""Step 4 - CTC keyword spotting.

For every sliding window we compute the CTC log-likelihood of the target string
(e.g. "ikhodi") and subtract the log-likelihood of the window's best (greedy) path.
LLR close to 0  => the target is almost as probable as the best transcription.
Windows of 0.6 / 0.8 / 1.0 / 1.3 s are tried, hits closer than 1.5 s are merged.

usage: python 04_keyword_spot.py posteriors.npy ikhodi,khodi,ikhoti
"""
import sys
import numpy as np
import torch

L = np.load(sys.argv[1])
targets = sys.argv[2].split(",")
chars = "abcdefghijklmnopqrstuvwxyz' "
cmap = {c: i + 1 for i, c in enumerate(chars)}          # col 0 = blank
lp = torch.from_numpy(L)
T = lp.shape[0]
FRAME_S = 0.02


def score(target, wlen, step=4, bs=256):
    tg = torch.tensor([cmap[c] for c in target])
    starts = list(range(0, T - wlen, step))
    res = []
    for k in range(0, len(starts), bs):
        ss = starts[k:k + bs]
        batch = torch.stack([lp[s:s + wlen] for s in ss], 1)          # (wlen, B, C)
        loss = torch.nn.functional.ctc_loss(
            batch, tg.unsqueeze(0).repeat(len(ss), 1),
            torch.full((len(ss),), wlen), torch.full((len(ss),), len(tg)),
            blank=0, reduction="none", zero_infinity=True)
        greedy = batch.max(2).values.sum(0)
        res += [(s, -l.item(), g.item()) for s, l, g in zip(ss, loss, greedy)]
    return res


for target in targets:
    hits = []
    for wlen in (30, 40, 50, 65):
        for s, sc, g in score(target, wlen):
            hits.append((sc - g, s * FRAME_S, wlen * FRAME_S, sc))
    hits.sort(reverse=True)
    picked = []
    for h in hits:
        if all(abs(h[1] - p[1]) > 1.5 for p in picked):
            picked.append(h)
        if len(picked) >= 12:
            break
    print("TARGET", repr(target))
    for llr, t, w, sc in picked:
        print(f"  t={t:7.2f}s win={w:.2f}s  LLR(vs greedy)={llr:7.2f}  logP={sc:7.2f}")
