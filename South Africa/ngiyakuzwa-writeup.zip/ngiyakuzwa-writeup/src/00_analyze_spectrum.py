#!/usr/bin/env python3
"""Step 0 - look at the recording.

 * prints the strongest stationary spectral lines (the vuvuzela harmonics)
 * optionally renders a spectrogram PNG of a time range

usage:
  python 00_analyze_spectrum.py lines  voice_note.wav
  python 00_analyze_spectrum.py spec   voice_note.wav T0 T1 out.png [FMAX] [VMIN] [VMAX]
"""
import sys
import numpy as np
import soundfile as sf
from scipy import signal


def lines(wav):
    x, sr = sf.read(wav)
    print(f"sr={sr} dur={len(x)/sr:.1f}s rms={np.sqrt((x**2).mean()):.4f} peak={abs(x).max():.3f}")
    f, P = signal.welch(x, sr, nperseg=8192)
    db = 10 * np.log10(P + 1e-20)
    pk = signal.find_peaks(db, prominence=6)[0]
    for i in sorted(sorted(pk, key=lambda i: -P[i])[:25]):
        print(f"{f[i]:8.1f} Hz  {db[i]:6.1f} dB")
    # -> peaks sit on two harmonic series: ~217.9*k and ~233.1*k (vuvuzelas)


def spec(wav, t0, t1, out, fmax=4000, vmin=-110, vmax=-30):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    x, sr = sf.read(wav)
    seg = x[int(t0 * sr):int(t1 * sr)]
    f, t, S = signal.spectrogram(seg, sr, nperseg=1024, noverlap=896)
    m = f <= fmax
    plt.figure(figsize=(14, 6))
    plt.pcolormesh(t + t0, f[m], 10 * np.log10(S[m] + 1e-12), shading="auto", vmin=vmin, vmax=vmax)
    plt.xlabel("time (s)"); plt.ylabel("Hz"); plt.colorbar(label="dB")
    plt.tight_layout(); plt.savefig(out, dpi=80)


if __name__ == "__main__":
    cmd = sys.argv[1]
    if cmd == "lines":
        lines(sys.argv[2])
    elif cmd == "spec":
        a = sys.argv[2:]
        spec(a[0], float(a[1]), float(a[2]), a[3], *(float(v) for v in a[4:7]))
