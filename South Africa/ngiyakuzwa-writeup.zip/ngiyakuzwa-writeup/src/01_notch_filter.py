#!/usr/bin/env python3
"""Step 1 - remove the vuvuzela drone with a per-frame adaptive harmonic notch.

The stadium noise is dominated by (at least) two steady vuvuzela tones whose
harmonics form two combs:  f0 ~ 217.9 Hz  and  f0 ~ 233.08 Hz (Bb3).
For every STFT frame we look near each expected harmonic, find the actual peak
(the tones drift slightly) and clamp the peak bins down to the local noise floor
(median over +-12 bins).  Phase is left untouched.

usage: python 01_notch_filter.py in.wav out.wav
"""
import sys
import numpy as np
import soundfile as sf
from scipy.signal import stft, istft
from scipy.ndimage import median_filter

FA, FB = 217.93, 233.09          # fundamentals of the two vuvuzela combs (Hz)
NPERSEG, HOP = 4096, 512         # 0.256 s window, 3.9 Hz bins


def main(inp, out):
    x, sr = sf.read(inp)
    f, t, X = stft(x, sr, window="hann", nperseg=NPERSEG,
                   noverlap=NPERSEG - HOP, boundary="zeros", padded=True)
    df = f[1] - f[0]
    mag, ph = np.abs(X), np.angle(X)
    floor = median_filter(mag, size=(25, 1), mode="nearest")   # local noise floor
    nb = X.shape[0]
    new = mag.copy()
    idx = np.arange(mag.shape[1])

    for f0 in (FA, FB):
        for k in range(1, int(7900 // f0) + 1):
            fk = k * f0
            sw = 0.6 + 0.07 * k                       # search half-width (Hz), grows with k
            lo = max(int(np.floor((fk - sw) / df)), 2)
            hi = min(int(np.ceil((fk + sw) / df)), nb - 3)
            pk = lo + np.argmax(mag[lo:hi + 1], axis=0)   # per-frame peak bin
            for d in range(-2, 3):                        # +-2 bins around the peak
                b = np.clip(pk + d, 0, nb - 1)
                new[b, idx] = np.minimum(new[b, idx], floor[b, idx])

    _, y = istft(new * np.exp(1j * ph), sr, window="hann", nperseg=NPERSEG,
                 noverlap=NPERSEG - HOP, boundary=True)
    y = y[:len(x)]
    sf.write(out, np.clip(y, -1, 1), sr, subtype="PCM_16")
    print(f"rms in {np.sqrt((x**2).mean()):.4f} -> out {np.sqrt((y**2).mean()):.4f}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
